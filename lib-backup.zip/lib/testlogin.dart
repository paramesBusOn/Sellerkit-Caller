// import 'dart:ui';

// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:sellerkitcalllog/helpers/screen.dart';

// class Login extends StatefulWidget {
//   const Login({super.key});

//   @override
//   State<Login> createState() => _LoginState();
// }

// class _LoginState extends State<Login> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         width: double.infinity,
//         height: double.infinity,
//         child: Stack(
//           // alignment: Alignment.center,
//           children: [
//             Container(
//               decoration: const BoxDecoration(
//                   // shape: BoxShape.circle,
//                   // color: Colors.red,
//                   image: DecorationImage(
//                       fit: BoxFit.fill,
//                       image: AssetImage('Assets/badminton-166415_1920.jpg'))),
//               height: Screens.bodyheight(context) * 0.45,
//               width: Screens.width(context),
//             ),
//             // Container(
//             //   decoration: BoxDecoration(
//             //       // shape: BoxShape.circle,
//             //       // color: Colors.red,
//             //       ),
//             //   height: Screens.bodyheight(context) * 0.45,
//             //   width: Screens.width(context),
//             // ),
//             // Positioned(
//             //   left: 15,
//             //   top: 15,
//             //   child: Container(
//             //     decoration: BoxDecoration(
//             //         // shape: BoxShape.circle,
//             //         color: Colors.lightBlue
//             //     ),
//             //     height: 30,
//             //     width: 30,
//             //   ),
//             // ),
//             Positioned(
//               top: 180,
//               child: Container(
//                 height: Screens.bodyheight(context) * 0.15,
//                 width: Screens.width(context),
//                 decoration: BoxDecoration(
//                   // color: const Color.fromARGB(255, 212, 188, 115),
//                   gradient: LinearGradient(
//                     begin: Alignment.topCenter,
//                     end: Alignment.center,
//                     colors: [
//                       const Color(0xFFFFFFFF),
//                       const Color(0x00000000),
//                     ],
//                   ),
//                 ),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
