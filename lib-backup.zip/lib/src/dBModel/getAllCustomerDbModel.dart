// import 'package:sellerkit/DBModel/EnqTypeModel.dart';

const String tableCustomerMaster = "CustomerMaster";

class CustomerMasterDB {
  //

  static const String alternateMobileNo = "alternateMobileNo";
  static const String assignedTo = "assignedTo";
  static const String bilAddress1 = "bilAddress1";
  static const String bilAddress2 = "bilAddress2";
  static const String bilAddress3 = "bilAddress3";
  static const String bilArea = "bilArea";
  static const String bilCity = "bilCity";
  static const String bilCountry = "bilCountry";
  static const String bilDistrict = "bilDistrict";
  static const String bilPincode = "bilPincode";
  static const String bilState = "bilState";
  static const String companyName = "companyName";
  static const String contactName = "contactName";
  static const String createdBy = "createdBy";
  static const String createdOn = "createdOn";
  static const String customerCode = "customerCode";
  static const String customerEmail = "customerEmail";
  static const String customerGroup = "customerGroup";
  static const String customerMobile = "customerMobile";
  static const String customerName = "customerName";
  static const String delAddress1 = "delAddress1";
  static const String delAddress2 = "delAddress2";
  static const String delAddress3 = "delAddress3";
  static const String delArea = "delArea";
  static const String delCity = "delCity";
  static const String delCountry = "delCountry";
  static const String delDistrict = "delDistrict";
  static const String delPincode = "delPincode";
  static const String delState = "delState";
  static const String gSTNo = "gSTNo";
  static const String pAN = "pAN";
  static const String status = "status";
  static const String storeCode = "storeCode";
  static const String updatedBy = "updatedBy";
  static const String updatedOn = "updatedOn";
  static const String traceid = "traceid";
}

class CustomerMasterDBModel {
  CustomerMasterDBModel({
    required this.alternateMobileNo,
    required this.assignedTo,
    required this.bilAddress1,
    required this.bilAddress2,
    required this.bilAddress3,
    required this.bilArea,
    required this.bilCity,
    required this.bilCountry,
    required this.bilDistrict,
    required this.bilPincode,
    required this.bilState,
    required this.companyName,
    required this.contactName,
    required this.createdBy,
    required this.createdOn,
    required this.customerCode,
    required this.customerEmail,
    required this.customerGroup,
    required this.customerMobile,
    required this.customerName,
    required this.delAddress1,
    required this.delAddress2,
    required this.delAddress3,
    required this.delArea,
    required this.delCity,
    required this.delCountry,
    required this.delDistrict,
    required this.delPincode,
    required this.delState,
    required this.gSTNo,
    required this.pAN,
    required this.status,
    required this.storeCode,
    required this.updatedBy,
    required this.updatedOn,
    required this.traceid,
  });
  String? alternateMobileNo;
  String? assignedTo;
  String? bilAddress1;
  String? bilAddress2;
  String? bilAddress3;
  String? bilArea;
  String? bilCity;
  String? bilCountry;
  String? bilDistrict;
  String? bilPincode;
  String? bilState;
  String? companyName;
  String? contactName;
  String? createdBy;
  String? createdOn;
  String? customerCode;
  String? customerEmail;
  String? customerGroup;
  String? customerMobile;
  String? customerName;
  String? delAddress1;
  String? delAddress2;
  String? delAddress3;
  String? delArea;
  String? delCity;
  String? delCountry;
  String? delDistrict;
  String? delPincode;
  String? delState;
  String? gSTNo;
  String? pAN;
  String? status;
  String? storeCode;
  String? updatedBy;
  String? updatedOn;
  String? traceid;

  Map<String, Object?> toMap() => {
        // CustomerMasterDB.cardcode:dateTime,
        // CustomerMasterDB.DateTime:filePath,

        CustomerMasterDB.alternateMobileNo: alternateMobileNo,
        CustomerMasterDB.assignedTo: assignedTo,
        CustomerMasterDB.bilAddress1: bilAddress1,
        CustomerMasterDB.bilAddress2: bilAddress2,
        CustomerMasterDB.bilAddress3: bilAddress3,
        CustomerMasterDB.bilArea: bilArea,
        CustomerMasterDB.bilCity: bilCity,
        CustomerMasterDB.bilCountry: bilCountry,
        CustomerMasterDB.bilDistrict: bilDistrict,
        CustomerMasterDB.bilPincode: bilPincode,
        CustomerMasterDB.bilState: bilState,
        CustomerMasterDB.companyName: companyName,
        CustomerMasterDB.contactName: assignedTo,
        CustomerMasterDB.createdBy: assignedTo,
        CustomerMasterDB.createdOn: assignedTo,
        CustomerMasterDB.customerCode: assignedTo,
        CustomerMasterDB.customerEmail: assignedTo,
        CustomerMasterDB.customerGroup: assignedTo,
        CustomerMasterDB.customerMobile: assignedTo,
        CustomerMasterDB.customerName: assignedTo,
        CustomerMasterDB.delAddress1: assignedTo,
        CustomerMasterDB.delAddress2: assignedTo,
        CustomerMasterDB.delAddress3: assignedTo,
        CustomerMasterDB.delArea: assignedTo,
        CustomerMasterDB.delCity: assignedTo,
        CustomerMasterDB.delCountry: assignedTo,
        CustomerMasterDB.delDistrict: assignedTo,
        CustomerMasterDB.delPincode: assignedTo,
        CustomerMasterDB.delState: assignedTo,
        CustomerMasterDB.gSTNo: assignedTo,
        CustomerMasterDB.pAN: assignedTo,
        CustomerMasterDB.status: assignedTo,
        CustomerMasterDB.storeCode: assignedTo,
        CustomerMasterDB.updatedBy: assignedTo,
        CustomerMasterDB.updatedOn: assignedTo,
        CustomerMasterDB.traceid: assignedTo,
      };
}
