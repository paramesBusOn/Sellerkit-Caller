class SegmentWiseModel {
  final DateTime time;
  final int sales;

  SegmentWiseModel(this.time, this.sales);
}