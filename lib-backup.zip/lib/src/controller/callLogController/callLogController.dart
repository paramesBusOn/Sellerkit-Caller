import 'dart:io';

import 'package:call_log/call_log.dart';
import 'package:flutter/material.dart';

import '../../../helpers/Utils.dart';
import '../../../helpers/constantApiUrl.dart';
import '../../../helpers/getCallLog_NativeCode.dart';
import '../../../helpers/helper.dart';
import '../../api/getCustomerApi/getCustomerApi.dart';

class CallLogController extends ChangeNotifier {
  CallLogController() {
    calllog();
  }
bool _disposed = false;

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }

  @override
  void notifyListeners() {
    if (!_disposed) {
      super.notifyListeners();
    }
  }
  List<Callloginfo> callsInfo = [];
  List<Contact> contactList = [];
  List<GetenquiryData>? customerDatalist = [];
  GetCallerData? callerList;
  bool apiloading = false;
  void calllog() async {
    apiloading = true;
    String? getToken = await HelperFunctions.getTokenSharedPreference();
    Utils.token = getToken;
    callsInfo = [];

    // if (callented == false) return;
    String mobileno = '';

    // getPermissionUser();
    if (Platform.isAndroid) {
      Iterable<CallLogEntry> entries = await CallLog.get();
      for (var item in entries) {
        // if (item.callType.toString().contains('incoming')) {

        mobileno = item.number!.replaceAll('+91', '');
        notifyListeners();
        String? getUrl = await HelperFunctions.getHostDSP();
        Utils.queryApi = 'http://${getUrl.toString()}/api/';
        String meth = '${ConstantApiUrl.getCustomerApi}';
        GetCutomerpost reqpost = GetCutomerpost(customermobile: mobileno);
        await GetCustomerDetailsApi.getData(meth, reqpost).then((value) {
          if (value.stcode! <= 210 && value.stcode! >= 200) {
            GetCustomerDetailsApitwo? itemdata;
            itemdata = value.itemdata;
            // List<EnqOrderList>? enqOrderlist = [];
            if (itemdata!.enquirydetails != null) {
              customerDatalist = [];

              for (int i = 0; i < itemdata.enquirydetails!.length; i++) {
                if (itemdata.enquirydetails![i].DocType == 'Order' ||
                    itemdata.enquirydetails![i].DocType == 'Outstanding' ||
                    itemdata.enquirydetails![i].DocType == 'Lead') {
                  customerDatalist!.add(GetenquiryData(
                      DocType: itemdata.enquirydetails![i].DocType,
                      AssignedTo: itemdata.enquirydetails![i].AssignedTo,
                      BusinessValue: itemdata.enquirydetails![i].BusinessValue,
                      CurrentStatus: itemdata.enquirydetails![i].CurrentStatus,
                      DocDate: itemdata.enquirydetails![i].DocDate,
                      DocNum: itemdata.enquirydetails![i].DocNum,
                      Status: itemdata.enquirydetails![i].Status,
                      Store: itemdata.enquirydetails![i].Store));
                  // enqOrderlist.add(EnqOrderList(
                  //     doctype: itemdata.enquirydetails![i].DocType,
                  //     docnum: itemdata.enquirydetails![i].DocNum.toString(),
                  //     lastorder: itemdata.enquirydetails![i].DocDate,
                  //     product: '----',
                  //     assignto: itemdata.enquirydetails![i].AssignedTo));
                }
              }
            }
            if (itemdata.customerdetails!.isNotEmpty) {
              // callerList = GetCallerData(
              //   name: itemdata.customerdetails![0].customerName,
              //   mobile: itemdata.customerdetails![0].mobileNo,
              //   tag: itemdata.customerdetails![0].customerGroup,
              //   calltype: callsInfo[0].name,
              //   // datalist: enqOrderlist,
              // );
              callsInfo.add(Callloginfo(
                  name: itemdata.customerdetails![0].customerName,
                  number: item.number,
                  customerTag: itemdata.customerdetails![0].customerGroup,
                  calltype: item.callType.toString()));
            } else {
              callsInfo.add(Callloginfo(
                  name: 'Unknown Number',
                  number: item.number,
                  customerTag: 'New',
                  calltype: item.callType.toString()));
              // callerList = GetCallerData(
              //     name: 'Unknown Number',
              //     mobile: mobileno,
              //     tag: 'new',
              //     calltype: callsInfo[0].name);
            }

            apiloading = false;

            notifyListeners();
          } else {
            callsInfo.add(Callloginfo(
                name: 'Unknown Number',
                number: item.number,
                customerTag: 'New',
                calltype: item.callType.toString()));
            apiloading = false;
          }
        });
        // log(item.callType.toString()+item.number.toString());
        // }
      }
    } else {
      List<Object?> result = await CallLogService.getCallLog();
      List<dynamic> listWithoutNulls =
          result.where((element) => element != null).toList();
      List<Contact> contacts = listWithoutNulls
          .map((item) => Contact(
                firstName: item['firstName'],
                lastName: item['lastName'],
                phoneNumbers: List<String>.from(item['phoneNumbers']),
              ))
          .toList();
      apiloading = false;

      notifyListeners();
    }
    
    notifyListeners();
  }
}

class Callloginfo {
  String? name;
  String? number;
  String? customerTag;
  String? calltype;
  Callloginfo(
      {this.name,
      required this.number,
      required this.customerTag,
      required this.calltype});
}

class Contact {
  String? firstName;
  String? lastName;
  List<dynamic>? phoneNumbers;

  Contact(
      {required this.firstName,
      required this.lastName,
      required this.phoneNumbers});

  factory Contact.fromJson(Map<String, dynamic> json) {
    return Contact(
      firstName: json['firstName'] ?? '',
      lastName: json['lastName'] ?? '',
      phoneNumbers: List<dynamic>.from(json['phoneNumbers'] ?? ''),
    );
  }
}

class GetCallerData {
  String? name;
  String? mobile;
  String? tag;
  String? calltype;
  // List<EnqOrderList>? datalist = [];
  GetCallerData({this.name, this.mobile, this.tag, required this.calltype
      // this.datalist,
      });
}
