// // ignore_for_file: prefer_const_constructors

// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:sellerkitcalllog/src/controller/dashboardController/dashboardController.dart';

// import '../../../../helpers/screen.dart';

// class OutStandingDetails extends StatefulWidget {
//   const OutStandingDetails({
//     Key? key,
//   }) : super(key: key);
//   @override
//   State<OutStandingDetails> createState() => _OutStandingDetailsState();
// }

// class _OutStandingDetailsState extends State<OutStandingDetails> {
//   @override
//   Widget build(BuildContext context) {
//     final theme = Theme.of(context);
//     return AlertDialog(
//       insetPadding: EdgeInsets.all(10),
//       contentPadding: EdgeInsets.all(0),
//       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
//       content: viewdetails(context, theme),
//     );
//   }

  
// }
