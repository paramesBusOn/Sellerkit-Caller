class ConstantRoutes {
  static String dashboard = "/Dashboard";
    static String loginwithSellerkit = "/loginwithSellerkit";
  static String splash = "/splash";
    static String onBoard = "/onBoard";
  static String download = "/download";
  static String restrictionValue = "/restrictionValue";
  static String login = "/login";
    static String callnotification = "/callnotification";
    static String newEnqpage = "/NewEnquiry";
    static String newCustomer = "/NewCustomer";
    static String callLog="/CallLog";


 }
